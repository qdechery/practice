module.exports = {
  options: {
    files: ['package.json', 'bower.json'],
    commitFiles: ['package.json', 'bower.json', 'CHANGELOG.md'],
    push: false
  }
};
