DEFAULTS = {
    "shirts": [
        "black",
        "green",
        "orange",
        "pink",
        "red",
        "teal",
        "purple"
    ],
    "pants": [
        "black",
        "blue",
        "green",
        "grey",
        "stars",
        "stripes",
        "tiger"
    ],
    "hat": [
        "black-baseball",
        "black-beanie",
        "bowler",
        "headband",
        "party",
        "pink-baseball",
        "pink-beanie"
    ],
    "glasses": [
        "optical-black",
        "optical-blue",
        "optical-purple",
        "optical-red",
        "optical-yellow",
        "sun-black",
        "sun-red"
    ],
    "footwear": [
        "sandal-pink",
        "sandal-purple",
        "shoes-black",
        "shoes-blue",
        "shoes-grey",
        "shoes-purple",
        "shoes-tiger"
    ],
    "colors": [
        "black",
        "purple",
        "blue",
        "green",
        "yellow",
        "orange",
        "red"
    ]
}
