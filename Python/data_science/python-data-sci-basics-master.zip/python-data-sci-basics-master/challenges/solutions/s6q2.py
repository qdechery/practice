from matplotlib.backends.backend_pdf import PdfPages

my_pdf = PdfPages('reports.pdf')

