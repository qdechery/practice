import matplotlib.pyplot as plt
plt.style.use('ggplot') 
fig = plt.figure() 
