import csv

def open_with_CSV(filename):
    data = []
    return data

