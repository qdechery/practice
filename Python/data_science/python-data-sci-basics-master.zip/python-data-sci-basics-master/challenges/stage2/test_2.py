import csv
filename = "data.csv"

def open_with_CSV(filename):
    data = []
    return data

try:
    output = ""
    assert
