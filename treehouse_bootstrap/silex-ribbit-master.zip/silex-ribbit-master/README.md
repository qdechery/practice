### Convert the Ribbit Promo Page to Silex App with Twig Templates

#### All Commits

1. add composer.json
2. add readme
3. install of silex by running *composer install*
4. add apache htaccess and our inital app file inside of a web folder
5. add twig and urlgenerator dependencies and a view placeholder
6. add our twig render without using a trait
7. add a traits by extending the application class, helpers are rad
8 add some twig to showcase syntax
9.  add gitignore for .ds_store
10. add inital files for conversion from ribbit promo page
11. modify the asssets path and clean up the modals and partials
12. clean up the mess with twig, using partials, blocks, and layouts
