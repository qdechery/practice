

/**
* When the JSON body is fully recieved the 
* the "end" event is triggered and the full body
* is given to the handler or callback
**/


/**
* If a parsing, network or HTTP error occurs an
* error object is passed in to the handler or callback
**/
