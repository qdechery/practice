import React from 'react';

const Single = React.createClass({
  render() {
    return (
      <div className="single-photo">
      I'm the single
      </div>
    )
  }
});

export default Single;
